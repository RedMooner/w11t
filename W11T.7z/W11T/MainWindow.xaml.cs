﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using W11T.Views;

namespace W11T
{
    public partial class MainWindow : Window
    {
  

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded; // Подписываемся на событие загрузки окна
            frame.Navigate(new TwaksView());
            frame.Navigate(new TwaksView());
        }
        private void EditTweaksButton_Click(object sender, RoutedEventArgs e)
        {
            EditTweaksWindow editWindow = new EditTweaksWindow();
            editWindow.Owner = this;
            editWindow.ShowDialog();
        }
        private void RegistryButton_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new TwaksView());
        }

        private void ServicesButton_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new ServicesPage());
        }
        private void ToggleView_Click(object sender, RoutedEventArgs e)
        {

            TwaksView.Instance.ToggleView();
        }
        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            await CheckForUpdatesAsync(); // Автоматическая проверка обновлений при загрузке окна
        }
        private async Task CheckForUpdatesAsync()
        {
            try
            {
                // Загрузка локальной версии
                string localVersion = File.ReadAllText("version.txt").Trim();

                // Загрузка версии с GitHub
                using (HttpClient client = new HttpClient())
                {
                    string githubVersionUrl = "https://raw.githubusercontent.com/RedMooner/w11t/main/version.txt";
                    string githubVersion = await client.GetStringAsync(githubVersionUrl).ConfigureAwait(false);
                    githubVersion = githubVersion.Trim();

                    // Загрузка описания с GitHub
                    string githubDescriptionUrl = "https://raw.githubusercontent.com/RedMooner/w11t/main/description.txt";
                    string githubDescription = await client.GetStringAsync(githubDescriptionUrl).ConfigureAwait(false);

                    // Сравнение версий
                    if (localVersion != githubVersion)
                    {
                        // Если версии разные, предлагаем обновление
                        var result = MessageBox.Show(
                            $"Доступна новая версия: {githubVersion}\n\nОписание:\n{githubDescription}\n\nХотите установить обновление?",
                            "Обновление доступно",
                            MessageBoxButton.YesNo,
                            MessageBoxImage.Information);

                        if (result == MessageBoxResult.Yes)
                        {
                            // Логика для установки обновления
                            MessageBox.Show("Обновление будет установлено...", "Установка обновления", MessageBoxButton.OK, MessageBoxImage.Information);
                            // Здесь можно добавить код для загрузки и установки обновления
                        }
                    }
                    else
                    {
                        // Если обновлений нет, выводим сообщение
                        //MessageBox.Show("У вас установлена последняя версия. Все хорошо!", "Проверка обновлений", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при проверке обновлений: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

      

        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new SettingsPage());
        }

        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new HelpPage());
        }
    }

   
}