﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;

namespace W11T
{
    public partial class MainWindow : Window
    {
        private ArrayOfTweak tweaks;
        private List<CategoryGroup> categoryGroups;
        private string _currentCategory = "Все категории";
        private bool _isTreeView = false; // Флаг для переключения между видами

        public MainWindow()
        {
            InitializeComponent();
            LoadTweaks();
            InitializeCategories();
        }

        private void LoadTweaks()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ArrayOfTweak));
            using (Stream reader = new FileStream("Tweaks.xml", FileMode.Open))
            {
                tweaks = (ArrayOfTweak)serializer.Deserialize(reader);
            }

            // Проверка текущего состояния каждой настройки
            foreach (var tweak in tweaks.Tweaks)
            {
                RegistryKey rootKey;
                switch (tweak.RegistryRoot)
                {
                    case "CurrentUser":
                        rootKey = Registry.CurrentUser;
                        break;
                    case "LocalMachine":
                        rootKey = Registry.LocalMachine;
                        break;
                    case "ClassesRoot":
                        rootKey = Registry.ClassesRoot;
                        break;
                    case "Users":
                        rootKey = Registry.Users;
                        break;
                    case "CurrentConfig":
                        rootKey = Registry.CurrentConfig;
                        break;
                    default:
                        continue;
                }

                using (RegistryKey key = rootKey.OpenSubKey(tweak.RegistryPath))
                {
                    if (key != null)
                    {
                        var currentValue = key.GetValue(tweak.ValueName, -1);
                        // Если OriginalValue не задан в XML, используем текущее значение из реестра
                        if (tweak.OriginalValue == 0) // Предполагаем, что 0 — значение по умолчанию
                        {
                            tweak.OriginalValue = (int)currentValue;
                        }
                        tweak.IsApplied = currentValue.Equals(tweak.Value); // Проверяем, применена ли настройка
                    }
                    else
                    {
                        tweak.OriginalValue = -1; // Если путь не существует
                        tweak.IsApplied = false;
                    }
                }
            }

            UpdateTweaksDisplay();
        }

        private void InitializeCategories()
        {
            var categories = tweaks.Tweaks.Select(t => t.Category).Distinct().ToList();
            CategoryButtons.ItemsSource = categories;
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            var toggleButton = sender as CheckBox;
            var tweak = toggleButton.Tag as Tweak;

            if (tweak == null) return;

            // Выбор корневой ветки реестра
            RegistryKey rootKey;
            switch (tweak.RegistryRoot)
            {
                case "CurrentUser":
                    rootKey = Registry.CurrentUser;
                    break;
                case "LocalMachine":
                    rootKey = Registry.LocalMachine;
                    break;
                case "ClassesRoot":
                    rootKey = Registry.ClassesRoot;
                    break;
                case "Users":
                    rootKey = Registry.Users;
                    break;
                case "CurrentConfig":
                    rootKey = Registry.CurrentConfig;
                    break;
                default:
                    MessageBox.Show("Неизвестная корневая ветка реестра.");
                    return;
            }

            // Работа с реестром
            using (RegistryKey key = rootKey.OpenSubKey(tweak.RegistryPath, true))
            {
                if (key == null)
                {
                    if (MessageBox.Show("Путь в реестре не существует. Создать?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        rootKey.CreateSubKey(tweak.RegistryPath);
                        MessageBox.Show("Путь создан. Примените настройку снова.");
                    }
                }
                else
                {
                    if (tweak.IsApplied)
                    {
                        // Возвращаем исходное значение
                        key.SetValue(tweak.ValueName, tweak.OriginalValue, RegistryValueKind.DWord);
                        tweak.IsApplied = false;
                        MessageBox.Show($"Настройка возвращена к исходному значению: {tweak.OriginalValue}");
                        toggleButton.IsChecked = false;

                    }
                    else
                    {
                        // Применяем новое значение
                        key.SetValue(tweak.ValueName, tweak.Value, RegistryValueKind.DWord);
                        toggleButton.IsChecked = true;
                        tweak.IsApplied = true;
                        MessageBox.Show($"Настройка применена: {tweak.Value}");
                    }
                }
            }

            // Обновляем отображение
            UpdateTweaksDisplay();
        }

        private void UpdateTweaksDisplay()
        {
            var filteredTweaks = tweaks.Tweaks;

            // Фильтрация по поисковому запросу
            if (!string.IsNullOrEmpty(SearchTextBox.Text))
            {
                filteredTweaks = filteredTweaks.Where(t => t.Name.Contains(SearchTextBox.Text, StringComparison.OrdinalIgnoreCase) ||
                                                          t.Description.Contains(SearchTextBox.Text, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            // Фильтрация по выбранной категории
            if (_currentCategory != "Все категории")
            {
                filteredTweaks = filteredTweaks.Where(t => t.Category == _currentCategory).ToList();
            }

            // Группировка по категориям
            categoryGroups = filteredTweaks.GroupBy(t => t.Category)
                                           .Select(g => new CategoryGroup { Category = g.Key, Tweaks = g.ToList() })
                                           .ToList();

            if (_isTreeView)
            {
                TreeView.ItemsSource = categoryGroups;
                TreeView.Visibility = Visibility.Visible;
                TilesView.Visibility = Visibility.Collapsed;

                // Подсветка включенных настроек
                foreach (var item in TreeView.Items)
                {
                    var container = TreeView.ItemContainerGenerator.ContainerFromItem(item) as TreeViewItem;
                    if (container != null)
                    {
                        foreach (var tweak in ((CategoryGroup)item).Tweaks)
                        {
                            var tweakContainer = container.ItemContainerGenerator.ContainerFromItem(tweak) as TreeViewItem;
                            if (tweakContainer != null)
                            {
                                tweakContainer.Background = tweak.IsApplied ? Brushes.Yellow : Brushes.Gray;
                            }
                        }
                    }
                }
            }
            else
            {
                TweaksItemsControl.ItemsSource = categoryGroups;
                TilesView.Visibility = Visibility.Visible;
                TreeView.Visibility = Visibility.Collapsed;

            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateTweaksDisplay();
        }

        private void ShowAllCategories_Click(object sender, RoutedEventArgs e)
        {
            _currentCategory = "Все категории";
            UpdateTweaksDisplay();
        }

        private void ShowCategory_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            _currentCategory = button.Tag as string;
            UpdateTweaksDisplay();
        }

        private void ToggleView_Click(object sender, RoutedEventArgs e)
        {
            _isTreeView = !_isTreeView; // Переключаем вид
            UpdateTweaksDisplay();
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void ApplyTweak_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var tweak = button.Tag as Tweak;


            // Выбор корневой ветки реестра
            RegistryKey rootKey;
            switch (tweak.RegistryRoot)
            {
                case "CurrentUser":
                    rootKey = Registry.CurrentUser;
                    break;
                case "LocalMachine":
                    rootKey = Registry.LocalMachine;
                    break;
                case "ClassesRoot":
                    rootKey = Registry.ClassesRoot;
                    break;
                case "Users":
                    rootKey = Registry.Users;
                    break;
                case "CurrentConfig":
                    rootKey = Registry.CurrentConfig;
                    break;
                default:
                    MessageBox.Show("Неизвестная корневая ветка реестра.");
                    return;
            }

            // Работа с реестром
            using (RegistryKey key = rootKey.OpenSubKey(tweak.RegistryPath, true))
            {
                if (key == null)
                {
                    if (MessageBox.Show("Путь в реестре не существует. Создать?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        rootKey.CreateSubKey(tweak.RegistryPath);
                        MessageBox.Show("Путь создан. Примените настройку снова.");
                    }
                }
                else
                {
                    if (tweak.IsApplied)
                    {
                        // Возвращаем исходное значение
                        key.SetValue(tweak.ValueName, tweak.OriginalValue, RegistryValueKind.DWord);

                        tweak.IsApplied = false;
                        MessageBox.Show($"Настройка возвращена к исходному значению: {tweak.OriginalValue}");
                    }
                    else
                    {
                        // Применяем новое значение
                        key.SetValue(tweak.ValueName, tweak.Value, RegistryValueKind.DWord);
                        tweak.IsApplied = true;
                        MessageBox.Show($"Настройка применена: {tweak.Value}");
                    }
                }
            }

            // Обновляем отображение
            UpdateTweaksDisplay();
        }

        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }

    public class CategoryGroup
    {
        public string Category { get; set; }
        public List<Tweak> Tweaks { get; set; }
    }
}