﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace W11T
{
    [XmlRoot(ElementName = "Tweak")]
    public class Tweak
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Category { get; set; } // Новое поле
        public string RegistryRoot { get; set; }
        public string RegistryPath { get; set; }
        public string ValueName { get; set; }
        public int Value { get; set; }
        public int OriginalValue { get; set; }
        public bool IsApplied { get; set; }
    }

    [XmlRoot(ElementName = "ArrayOfTweak")]
    public class ArrayOfTweak
    {
        [XmlElement(ElementName = "Tweak")]
        public List<Tweak> Tweaks { get; set; }
    }
}
