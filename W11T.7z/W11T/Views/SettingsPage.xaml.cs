﻿using System;
using System.IO;
using System.Net.Http;
using System.Windows;
using System.Windows.Controls;

namespace W11T.Views
{
    public partial class SettingsPage : Page
    {
        public SettingsPage()
        {
            InitializeComponent();
            CheckUpdates_Click(null,null);
        }

        // Обработчик кнопки "Назад"
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
            else
            {
                MessageBox.Show("Нет предыдущей страницы для возврата.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Обработчик кнопки "Сбросить все настройки"
        private void ResetSettings_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите сбросить все настройки? Это действие нельзя отменить.",
                                         "Подтверждение сброса",
                                         MessageBoxButton.YesNo,
                                         MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                // Логика сброса всех настроек
                ResetAllTweaks();
                MessageBox.Show("Все настройки сброшены.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Метод для сброса всех настроек
        private void ResetAllTweaks()
        {
            // Логика сброса настроек (например, восстановление исходных значений в реестре)
            // Это можно реализовать, пройдя по всем настройкам и вернув их OriginalValue
        }

        // Обработчик кнопки "Проверить обновления"
        private async void CheckUpdates_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Загрузка локальной версии
                string localVersion = File.ReadAllText("version.txt").Trim();

                // Загрузка версии с GitHub
                using (HttpClient client = new HttpClient())
                {
                    string githubVersionUrl = "https://raw.githubusercontent.com/RedMooner/w11t/main/version.txt";
                    string githubVersion = await client.GetStringAsync(githubVersionUrl).ConfigureAwait(false);
                    githubVersion = githubVersion.Trim();

                    // Загрузка описания с GitHub
                    string githubDescriptionUrl = "https://raw.githubusercontent.com/RedMooner/w11t/main/description.txt";
                    string githubDescription = await client.GetStringAsync(githubDescriptionUrl).ConfigureAwait(false);

                    // Используем Dispatcher для обновления UI
                    Dispatcher.Invoke(() =>
                    {
                        // Сравнение версий
                        if (localVersion != githubVersion)
                        {
                            VersionText.Text = $"Доступна новая версия: {githubVersion}";
                            DescriptionText.Text = githubDescription;
                            VersionPanel.Visibility = Visibility.Visible;
                        }
                        else
                        {
                            if(sender != null)
                                MessageBox.Show("У вас установлена последняя версия.", "Проверка обновлений", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                // Используем Dispatcher для отображения ошибки
                Dispatcher.Invoke(() =>
                {
                    MessageBox.Show($"Ошибка при проверке обновлений: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                });
            }
        }
    }
}