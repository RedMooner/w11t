﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Xml.Serialization;
using W11T.Views;

namespace W11T
{
    public partial class EditTweaksWindow : Window
    {
        private List<Tweak> _tweaks;

        public EditTweaksWindow()
        {
            InitializeComponent();
            LoadTweaks();
        }

        private void LoadTweaks()
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ArrayOfTweak));
                using (FileStream fs = new FileStream("Tweaks.xml", FileMode.Open))
                {
                    ArrayOfTweak tweaks = (ArrayOfTweak)serializer.Deserialize(fs);
                    _tweaks = tweaks.Tweaks;
                    TweaksDataGrid.ItemsSource = _tweaks;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке твиков: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveTweaks()
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ArrayOfTweak));
                using (FileStream fs = new FileStream("Tweaks.xml", FileMode.Create))
                {
                    ArrayOfTweak tweaks = new ArrayOfTweak { Tweaks = _tweaks };
                    serializer.Serialize(fs, tweaks);
                }
                TwaksView.Instance.LoadTweaks();
                TwaksView.Instance.InitializeCategories();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении твиков: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddTweak_Click(object sender, RoutedEventArgs e)
        {
            _tweaks.Add(new Tweak
            {
                Name = "Новый твик",
                Description = "Описание",
                Category = "Категория",
                RegistryRoot = "CurrentUser",
                RegistryPath = "Путь",
                ValueName = "Имя значения",
                Value = 0,
                OriginalValue = 0
            });
            TweaksDataGrid.Items.Refresh();
        }

        private void DeleteTweak_Click(object sender, RoutedEventArgs e)
        {
            if (TweaksDataGrid.SelectedItem is Tweak selectedTweak)
            {
                _tweaks.Remove(selectedTweak);
                TweaksDataGrid.Items.Refresh();
            }
        }

        private void SaveTweaks_Click(object sender, RoutedEventArgs e)
        {
            SaveTweaks();
            MessageBox.Show("Твики успешно сохранены!", "Сохранение", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}