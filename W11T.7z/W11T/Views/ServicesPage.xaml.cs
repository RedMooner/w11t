﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Serialization;

namespace W11T.Views
{
    public partial class ServicesPage : Page
    {
        private List<Service> _services;
        private List<ServiceCategoryGroup> _categoryGroups;
        private string _currentCategory = "Все категории";

        public ServicesPage()
        {
            InitializeComponent();
            LoadServices();
            InitializeCategories();
        }

        private void LoadServices()
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<Service>), new XmlRootAttribute("ArrayOfService"));
                using (FileStream fs = new FileStream("services.xml", FileMode.Open))
                {
                    _services = (List<Service>)serializer.Deserialize(fs);
                }

                UpdateServicesDisplay();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке служб: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InitializeCategories()
        {
            var categories = _services.Select(s => s.Category).Distinct().ToList();
            CategoryButtons.ItemsSource = categories;
        }

        private void UpdateServicesDisplay()
        {
            var filteredServices = _services;

            // Фильтрация по поисковому запросу
            if (!string.IsNullOrEmpty(SearchTextBox.Text))
            {
                filteredServices = filteredServices.Where(s => s.Name.Contains(SearchTextBox.Text, StringComparison.OrdinalIgnoreCase) ||
                                                    s.Description.Contains(SearchTextBox.Text, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            // Фильтрация по выбранной категории
            if (_currentCategory != "Все категории")
            {
                filteredServices = filteredServices.Where(s => s.Category == _currentCategory).ToList();
            }

            // Группировка по категориям
            _categoryGroups = filteredServices.GroupBy(s => s.Category)
                                             .Select(g => new ServiceCategoryGroup { Category = g.Key, Services = g.ToList() })
                                             .ToList();

            ServicesTreeView.ItemsSource = _categoryGroups;
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            var checkBox = sender as CheckBox;
            var service = checkBox.Tag as Service;

            if (service == null) return;

            service.ChangeState(checkBox.IsChecked ?? false);
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateServicesDisplay();
        }

        private void ShowAllCategories_Click(object sender, RoutedEventArgs e)
        {
            _currentCategory = "Все категории";
            UpdateServicesDisplay();
        }

        private void ShowCategory_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            _currentCategory = button.Tag as string;
            UpdateServicesDisplay();
        }
    }

    public class ServiceCategoryGroup
    {
        public string Category { get; set; }
        public List<Service> Services { get; set; }
    }
}