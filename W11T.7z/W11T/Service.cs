﻿using System.Diagnostics;
using System.Windows;

namespace W11T.Views
{
    public class Service
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string ServiceName { get; set; }
        public string Category { get; set; }
        public bool OriginalState { get; set; }
        public bool TargetState { get; set; }
        public bool IsApplied { get; set; }

        public void ChangeState(bool newState)
        {
            try
            {
                // Команда для изменения типа запуска службы
                string startupTypeCommand = $"Set-Service -Name {ServiceName} -StartupType {(newState ? "Automatic" : "Disabled")}";

                // Команда для немедленного запуска или остановки службы
                string serviceStateCommand = newState ? $"Start-Service -Name {ServiceName}" : $"Stop-Service -Name {ServiceName}";

                // Объединяем команды в один вызов PowerShell
                string fullCommand = $"{startupTypeCommand}; {serviceStateCommand}";

                var startInfo = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = $"-Command \"{fullCommand}\"",
                    Verb = "runas", // Запуск от имени администратора
                    UseShellExecute = true,
                    CreateNoWindow = true
                };

                using (var process = Process.Start(startInfo))
                {
                    process.WaitForExit();
                    if (process.ExitCode == 0)
                    {
                        IsApplied = newState;
                    }
                    else
                    {
                        MessageBox.Show($"Не удалось изменить состояние службы {Name}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при изменении состояния службы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}