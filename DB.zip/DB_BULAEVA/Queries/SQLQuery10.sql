-- Количество автомобилей по маркам
SELECT Make, COUNT(*) AS CarCount
FROM Cars
GROUP BY Make
ORDER BY CarCount DESC;

-- Средняя стоимость услуг по категориям (по первой букве названия)
SELECT 
    LEFT(ServiceName, 1) AS Category,
    COUNT(*) AS ServiceCount,
    AVG(BasePrice) AS AvgPrice,
    MIN(BasePrice) AS MinPrice,
    MAX(BasePrice) AS MaxPrice
FROM Services
GROUP BY LEFT(ServiceName, 1)
ORDER BY Category;

-- Количество заказов по сотрудникам (с сортировкой)
SELECT 
    EmployeeID,
    COUNT(*) AS TotalOrders,
    MIN(AcceptanceDate) AS FirstOrder,
    MAX(AcceptanceDate) AS LastOrder
FROM Orders
GROUP BY EmployeeID
ORDER BY TotalOrders DESC;

-- Статистика по статусам заказов
SELECT 
    StatusID,
    COUNT(*) AS OrdersCount,
    COUNT(ActualDate) AS CompletedOrders,  -- считаем только не-NULL
    AVG(DATEDIFF(day, AcceptanceDate, ActualDate)) AS AvgCompletionDays
FROM Orders
GROUP BY StatusID;