-- Статистика по сотрудникам за определенный период
SELECT 
    e.FullName,
    e.Position,
    COUNT(DISTINCT o.OrderID) AS TotalOrders,
    COUNT(DISTINCT ca.ClientID) AS UniqueClients,
    SUM(DISTINCT ISNULL(os.ActualPrice, s.BasePrice) * os.Quantity) AS TotalServicesRevenue,
    SUM(p.Price * op.Quantity) AS TotalPartsSold,
    AVG(DATEDIFF(hour, o.AcceptanceDate, o.ActualDate)) AS AvgCompletionHours
FROM Employees e
LEFT JOIN Orders o ON e.EmployeeID = o.EmployeeID 
    AND o.AcceptanceDate BETWEEN '2024-01-15' AND '2024-01-31'
LEFT JOIN Cars ca ON o.CarID = ca.CarID
LEFT JOIN OrderServices os ON o.OrderID = os.OrderID
LEFT JOIN Services s ON os.ServiceID = s.ServiceID
LEFT JOIN OrderParts op ON o.OrderID = op.OrderID
LEFT JOIN Parts p ON op.PartID = p.PartID
WHERE e.Position LIKE '%механик%'  -- шаблон
GROUP BY e.FullName, e.Position
HAVING COUNT(o.OrderID) > 0  -- только сотрудники с заказами
ORDER BY TotalOrders DESC, TotalServicesRevenue DESC;

-- Анализ популярности услуг
SELECT 
    s.ServiceName,
    COUNT(os.OrderServiceID) AS TimesOrdered,
    SUM(os.Quantity) AS TotalQuantity,
    AVG(ISNULL(os.ActualPrice, s.BasePrice)) AS AvgActualPrice,
    SUM(ISNULL(os.ActualPrice, s.BasePrice) * os.Quantity) AS TotalRevenue
FROM Services s
LEFT JOIN OrderServices os ON s.ServiceID = os.ServiceID
LEFT JOIN Orders o ON os.OrderID = o.OrderID 
    AND o.StatusID IN (3, 4)  -- только готовые и выданные заказы
WHERE s.BasePrice BETWEEN 500 AND 5000  -- диапазон цен
GROUP BY s.ServiceName
HAVING COUNT(os.OrderServiceID) >= 1  -- услуги, которые заказывали
ORDER BY TotalRevenue DESC, TimesOrdered DESC;