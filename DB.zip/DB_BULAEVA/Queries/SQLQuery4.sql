CREATE DATABASE AutoServiceDB
COLLATE Cyrillic_General_CI_AS;  -- CI = Case Insensitive, AS = Accent Sensitive
GO

-- Создание базы данных
CREATE DATABASE AutoServiceDB;
GO

USE AutoServiceDB;
GO

-- 1. СОТРУДНИКИ (Employees)
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY IDENTITY(1,1),
    FullName NVARCHAR(100) NOT NULL,
    PhoneNumber NVARCHAR(20) NOT NULL UNIQUE,
    Position NVARCHAR(50) NOT NULL DEFAULT 'Механик'
);
GO

-- 2. КЛИЕНТЫ (Clients)
CREATE TABLE Clients (
    ClientID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    PhoneNumber NVARCHAR(20) NOT NULL UNIQUE,
    Email NVARCHAR(100),
    RegistrationDate DATETIME2 NOT NULL DEFAULT GETDATE()
);
GO

-- 3. АВТОМОБИЛИ (Cars)
CREATE TABLE Cars (
    CarID INT PRIMARY KEY IDENTITY(1,1),
    ClientID INT NOT NULL,
    Make NVARCHAR(50) NOT NULL,
    Model NVARCHAR(50) NOT NULL,
    Year INT,
    VIN NVARCHAR(17) UNIQUE,
    LicensePlate NVARCHAR(15) UNIQUE,
    -- Ограничение на год выпуска
    CONSTRAINT CK_Car_Year CHECK (Year BETWEEN 1900 AND YEAR(GETDATE())),
    -- Внешний ключ
    CONSTRAINT FK_Cars_Clients FOREIGN KEY (ClientID) REFERENCES Clients(ClientID) ON DELETE CASCADE
);ЫЫ
GO

-- 4. СТАТУСЫ ЗАКАЗА (OrderStatuses)
CREATE TABLE OrderStatuses (
    StatusID INT PRIMARY KEY IDENTITY(1,1),
    StatusName NVARCHAR(50) NOT NULL UNIQUE
);
GO

-- 5. УСЛУГИ (Services)
CREATE TABLE Services (
    ServiceID INT PRIMARY KEY IDENTITY(1,1),
    ServiceName NVARCHAR(200) NOT NULL,
    StandardTime DECIMAL(5,2),
    BasePrice DECIMAL(10,2) NOT NULL,
    -- Ограничения цен и времени
    CONSTRAINT CK_Service_Price CHECK (BasePrice >= 0),
    CONSTRAINT CK_Service_Time CHECK (StandardTime > 0)
);
GO

-- 6. ЗАПЧАСТИ (Parts)
CREATE TABLE Parts (
    PartID INT PRIMARY KEY IDENTITY(1,1),
    PartNumber NVARCHAR(50) NOT NULL UNIQUE,
    PartName NVARCHAR(200) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    -- Ограничение цены
    CONSTRAINT CK_Part_Price CHECK (Price >= 0)
);Ы
GO

-- 7. ЗАКАЗЫ (Orders)
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    OrderNumber AS 'ЗАКАЗ-' + RIGHT('0000' + CAST(OrderID AS NVARCHAR(4)), 4) PERSISTED,
    CarID INT NOT NULL,
    StatusID INT NOT NULL,
    EmployeeID INT NOT NULL,
    AcceptanceDate DATETIME2 NOT NULL DEFAULT GETDATE(),
    PlannedDate DATE,
    ActualDate DATETIME2,
    Notes NVARCHAR(500),
    -- Внешние ключи
    CONSTRAINT FK_Orders_Cars FOREIGN KEY (CarID) REFERENCES Cars(CarID),
    CONSTRAINT FK_Orders_Statuses FOREIGN KEY (StatusID) REFERENCES OrderStatuses(StatusID),
    CONSTRAINT FK_Orders_Employees FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID),
    -- Ограничение дат
    CONSTRAINT CK_Order_Dates CHECK (PlannedDate >= CAST(AcceptanceDate AS DATE) OR PlannedDate IS NULL)
);
GO

-- 8. УСЛУГИ В ЗАКАЗЕ (OrderServices)
CREATE TABLE OrderServices (
    OrderServiceID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    ServiceID INT NOT NULL,
    Quantity INT NOT NULL DEFAULT 1,
    ActualPrice DECIMAL(10,2),
    Comment NVARCHAR(500),
    -- Внешние ключи
    CONSTRAINT FK_OrderServices_Orders FOREIGN KEY (OrderID) REFERENCES Orders(OrderID) ON DELETE CASCADE,
    CONSTRAINT FK_OrderServices_Services FOREIGN KEY (ServiceID) REFERENCES Services(ServiceID),
    -- Ограничения
    CONSTRAINT CK_OrderServices_Quantity CHECK (Quantity > 0),
    CONSTRAINT CK_OrderServices_Price CHECK (ActualPrice >= 0 OR ActualPrice IS NULL)
);
GO

-- 9. ЗАПЧАСТИ В ЗАКАЗЕ (OrderParts)
CREATE TABLE OrderParts (
    OrderPartID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    PartID INT NOT NULL,
    Quantity INT NOT NULL DEFAULT 1,
    -- Внешние ключи
    CONSTRAINT FK_OrderParts_Orders FOREIGN KEY (OrderID) REFERENCES Orders(OrderID) ON DELETE CASCADE,
    CONSTRAINT FK_OrderParts_Parts FOREIGN KEY (PartID) REFERENCES Parts(PartID),
    -- Ограничение количества
    CONSTRAINT CK_OrderParts_Quantity CHECK (Quantity > 0)
);
GO

-- ============================================
-- ЗАПОЛНЕНИЕ СПРАВОЧНИКОВ (русские названия)
-- ============================================

-- Статусы заказов
INSERT INTO OrderStatuses (StatusName) VALUES ('Принят');
INSERT INTO OrderStatuses (StatusName) VALUES ('В работе');
INSERT INTO OrderStatuses (StatusName) VALUES ('Готов');
INSERT INTO OrderStatuses (StatusName) VALUES ('Выдан');
INSERT INTO OrderStatuses (StatusName) VALUES ('Отменен');

-- Сотрудники
INSERT INTO Employees (FullName, PhoneNumber, Position) 
VALUES ('Иванов Иван Петрович', '+7-999-111-22-33', 'Старший механик');

INSERT INTO Employees (FullName, PhoneNumber, Position) 
VALUES ('Петров Петр Иванович', '+7-999-444-55-66', 'Механик');

INSERT INTO Employees (FullName, PhoneNumber) 
VALUES ('Сидоров Алексей Владимирович', '+7-999-777-88-99');

-- Услуги
INSERT INTO Services (ServiceName, StandardTime, BasePrice) 
VALUES ('Замена масла', 1.0, 1500.00);

INSERT INTO Services (ServiceName, StandardTime, BasePrice) 
VALUES ('Диагностика двигателя', 2.0, 2500.00);

INSERT INTO Services (ServiceName, StandardTime, BasePrice) 
VALUES ('Замена тормозных колодок', 1.5, 2000.00);

INSERT INTO Services (ServiceName, StandardTime, BasePrice) 
VALUES ('Ремонт подвески', 3.0, 4500.00);

INSERT INTO Services (ServiceName, StandardTime, BasePrice) 
VALUES ('Компьютерная диагностика', 0.5, 1000.00);

-- Запчасти
INSERT INTO Parts (PartNumber, PartName, Price) 
VALUES ('OIL-001', 'Масло моторное 5W40 (4л)', 2500.00);

INSERT INTO Parts (PartNumber, PartName, Price) 
VALUES ('FLT-001', 'Фильтр масляный', 350.00);

INSERT INTO Parts (PartNumber, PartName, Price) 
VALUES ('BRK-001', 'Колодки тормозные передние', 1800.00);

INSERT INTO Parts (PartNumber, PartName, Price) 
VALUES ('BRK-002', 'Колодки тормозные задние', 1650.00);

INSERT INTO Parts (PartNumber, PartName, Price) 
VALUES ('FLT-002', 'Фильтр воздушный', 450.00);

-- Клиенты
INSERT INTO Clients (FirstName, LastName, PhoneNumber, Email) 
VALUES ('Александр', 'Смирнов', '+7-911-111-11-11', 'smirnov@mail.ru');

INSERT INTO Clients (FirstName, LastName, PhoneNumber) 
VALUES ('Елена', 'Петрова', '+7-922-222-22-22');

INSERT INTO Clients (FirstName, LastName, PhoneNumber, Email) 
VALUES ('Дмитрий', 'Иванов', '+7-933-333-33-33', 'd.ivanov@yandex.ru');

-- Автомобили
INSERT INTO Cars (ClientID, Make, Model, Year, VIN, LicensePlate) 
VALUES (1, 'Toyota', 'Camry', 2019, 'JTDBE32K001234567', 'А123ВВ777');

INSERT INTO Cars (ClientID, Make, Model, Year, VIN, LicensePlate) 
VALUES (1, 'Honda', 'CR-V', 2020, 'JHMEH32K008765432', 'В456ВС777');

INSERT INTO Cars (ClientID, Make, Model, Year, VIN, LicensePlate) 
VALUES (2, 'BMW', 'X5', 2018, 'WBAFE123456789012', 'Е789КХ178');

INSERT INTO Cars (ClientID, Make, Model, Year, LicensePlate) 
VALUES (3, 'Kia', 'Rio', 2021, 'М123ОР799');

-- ============================================
-- СОЗДАНИЕ ЗАКАЗОВ
-- ============================================

-- Заказ 1: Для автомобиля Toyota
INSERT INTO Orders (CarID, StatusID, EmployeeID, AcceptanceDate, PlannedDate, Notes)
VALUES (1, 1, 1, '2024-01-15 10:30:00', '2024-01-15 14:00:00', 'Плановое ТО');

-- Добавляем услуги в заказ 1
INSERT INTO OrderServices (OrderID, ServiceID, Quantity, Comment)
VALUES (1, 1, 1, 'Замена масла и фильтра');

INSERT INTO OrderServices (OrderID, ServiceID, Quantity, Comment)
VALUES (1, 5, 1, 'Проверка ошибок');

-- Добавляем запчасти в заказ 1
INSERT INTO OrderParts (OrderID, PartID, Quantity)
VALUES (1, 1, 1);  -- Масло

INSERT INTO OrderParts (OrderID, PartID, Quantity)
VALUES (1, 2, 1);  -- Фильтр

-- Заказ 2: Для автомобиля BMW
INSERT INTO Orders (CarID, StatusID, EmployeeID, AcceptanceDate, PlannedDate, Notes)
VALUES (3, 2, 2, '2024-01-16 09:15:00', '2024-01-16 17:00:00', 'Стук в подвеске');

-- Добавляем услуги в заказ 2
INSERT INTO OrderServices (OrderID, ServiceID, Quantity)
VALUES (2, 4, 1);  -- Ремонт подвески

INSERT INTO OrderServices (OrderID, ServiceID, Quantity)
VALUES (2, 2, 1);  -- Диагностика

-- Добавляем запчасти в заказ 2
INSERT INTO OrderParts (OrderID, PartID, Quantity)
VALUES (2, 3, 2);  -- Колодки передние (2 шт)

-- Заказ 3: Для автомобиля Kia
INSERT INTO Orders (CarID, StatusID, EmployeeID, AcceptanceDate, Notes)
VALUES (4, 3, 3, '2024-01-16 14:00:00', 'Замена колодок');

-- Добавляем услуги в заказ 3
INSERT INTO OrderServices (OrderID, ServiceID, Quantity)
VALUES (3, 3, 1);  -- Замена колодок

-- Добавляем запчасти в заказ 3
INSERT INTO OrderParts (OrderID, PartID, Quantity)
VALUES (3, 3, 2);  -- Колодки передние

INSERT INTO OrderParts (OrderID, PartID, Quantity)
VALUES (3, 4, 2);  -- Колодки задние

-- ============================================
-- ПРОСТЫЕ ЗАПРОСЫ ДЛЯ ПРОВЕРКИ
-- ============================================

-- 1. Посмотреть всех клиентов
SELECT * FROM Clients;

-- 2. Посмотреть все автомобили с владельцами
SELECT 
    c.LicensePlate AS 'Госномер',
    c.Make AS 'Марка',
    c.Model AS 'Модель',
    c.Year AS 'Год',
    cl.LastName + ' ' + cl.FirstName AS 'Владелец'
FROM Cars c
JOIN Clients cl ON c.ClientID = cl.ClientID;

-- 3. Посмотреть все заказы
SELECT 
    OrderNumber AS 'Номер заказа',
    AcceptanceDate AS 'Дата приема',
    PlannedDate AS 'Плановая дата',
    Notes AS 'Примечания'
FROM Orders;

-- 4. Посчитать стоимость заказа №1
-- Стоимость услуг
SELECT 'Услуги' AS 'Тип', SUM(s.BasePrice * os.Quantity) AS 'Сумма'
FROM OrderServices os
JOIN Services s ON os.ServiceID = s.ServiceID
WHERE os.OrderID = 1
UNION ALL
-- Стоимость запчастей
SELECT 'Запчасти' AS 'Тип', SUM(p.Price * op.Quantity) AS 'Сумма'
FROM OrderParts op
JOIN Parts p ON op.PartID = p.PartID
WHERE op.OrderID = 1
UNION ALL
-- ИТОГО
SELECT 'ИТОГО' AS 'Тип', 
    ISNULL((SELECT SUM(s.BasePrice * os.Quantity) FROM OrderServices os JOIN Services s ON os.ServiceID = s.ServiceID WHERE os.OrderID = 1), 0) +
    ISNULL((SELECT SUM(p.Price * op.Quantity) FROM OrderParts op JOIN Parts p ON op.PartID = p.PartID WHERE op.OrderID = 1), 0) AS 'Сумма';

-- 5. Детали заказа №1 (все услуги и запчасти)
SELECT 
    'Услуга' AS 'Вид',
    s.ServiceName AS 'Наименование',
    os.Quantity AS 'Кол-во',
    s.BasePrice AS 'Цена',
    s.BasePrice * os.Quantity AS 'Сумма',
    os.Comment AS 'Комментарий'
FROM OrderServices os
JOIN Services s ON os.ServiceID = s.ServiceID
WHERE os.OrderID = 1
UNION ALL
SELECT 
    'Запчасть' AS 'Вид',
    p.PartName AS 'Наименование',
    op.Quantity AS 'Кол-во',
    p.Price AS 'Цена',
    p.Price * op.Quantity AS 'Сумма',
    '' AS 'Комментарий'
FROM OrderParts op
JOIN Parts p ON op.PartID = p.PartID
WHERE op.OrderID = 1;

-- 6. Заказы по сотрудникам
SELECT 
    e.FullName AS 'Сотрудник',
    COUNT(o.OrderID) AS 'Количество заказов',
    MIN(o.AcceptanceDate) AS 'Первый заказ',
    MAX(o.AcceptanceDate) AS 'Последний заказ'
FROM Employees e
LEFT JOIN Orders o ON e.EmployeeID = o.EmployeeID
GROUP BY e.FullName;

-- 7. Популярные услуги
SELECT 
    s.ServiceName AS 'Услуга',
    COUNT(os.OrderServiceID) AS 'Сколько раз заказывали',
    SUM(os.Quantity) AS 'Общее количество'
FROM Services s
LEFT JOIN OrderServices os ON s.ServiceID = os.ServiceID
GROUP BY s.ServiceName
ORDER BY COUNT(os.OrderServiceID) DESC;

-- 8. Заказы по статусам
SELECT 
    os.StatusName AS 'Статус',
    COUNT(o.OrderID) AS 'Количество заказов'
FROM OrderStatuses os
LEFT JOIN Orders o ON os.StatusID = o.StatusID
GROUP BY os.StatusName;

-- 9. Общая выручка
SELECT 
    SUM(service_sum + part_sum) AS 'Общая выручка'
FROM (
    SELECT 
        o.OrderID,
        ISNULL((SELECT SUM(s.BasePrice * os.Quantity) FROM OrderServices os JOIN Services s ON os.ServiceID = s.ServiceID WHERE os.OrderID = o.OrderID), 0) AS service_sum,
        ISNULL((SELECT SUM(p.Price * op.Quantity) FROM OrderParts op JOIN Parts p ON op.PartID = p.PartID WHERE op.OrderID = o.OrderID), 0) AS part_sum
    FROM Orders o
) AS order_totals;

-- 10. Проверка ограничений (попытка вставить неверные данные)
-- Раскомментируйте для проверки:

-- Ошибка: отрицательная цена услуги
-- INSERT INTO Services (ServiceName, BasePrice) VALUES ('Тест', -100);

-- Ошибка: год автомобиля раньше 1900
-- INSERT INTO Cars (ClientID, Make, Model, Year) VALUES (1, 'Test', 'Test', 1800);

-- Ошибка: план раньше даты приема
-- INSERT INTO Orders (CarID, StatusID, EmployeeID, AcceptanceDate, PlannedDate) 
-- VALUES (1, 1, 1, '2024-01-20', '2024-01-19');