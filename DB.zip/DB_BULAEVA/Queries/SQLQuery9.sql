-- Сортировка клиентов по фамилии и имени (по возрастанию)
SELECT LastName, FirstName, PhoneNumber, RegistrationDate
FROM Clients
ORDER BY LastName, FirstName;

-- Сортировка заказов по дате принятия (от новых к старым)
SELECT OrderNumber, AcceptanceDate, StatusID
FROM Orders
ORDER BY AcceptanceDate DESC;

-- Сортировка автомобилей по марке, затем по году выпуска (убывание)
SELECT Make, Model, Year, LicensePlate
FROM Cars
ORDER BY Make, Year DESC;


SELECT ServiceName, BasePrice, StandardTime
FROM Services
WHERE BasePrice > 1500
ORDER BY BasePrice DESC, StandardTime;


