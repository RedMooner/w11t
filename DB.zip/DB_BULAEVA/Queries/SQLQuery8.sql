-- Найти клиентов без email
SELECT FirstName, LastName, PhoneNumber
FROM Clients
WHERE Email IS NULL;

-- Найти автомобили без VIN-номера
SELECT Make, Model, Year, LicensePlate
FROM Cars
WHERE VIN IS NULL;

-- Найти заказы, где не указана плановая дата
SELECT OrderNumber, AcceptanceDate, PlannedDate, Notes
FROM Orders
WHERE PlannedDate IS NULL;

-- Найти услуги в заказах с указанной фактической ценой
SELECT OrderID, ServiceID, Quantity, ActualPrice, Comment
FROM OrderServices
