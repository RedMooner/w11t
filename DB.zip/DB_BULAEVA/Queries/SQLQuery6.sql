-- Найти автомобили 2018-2020 годов выпуска
SELECT Make, Model, Year, LicensePlate
FROM Cars
WHERE Year BETWEEN 2018 AND 2020;

-- Найти заказы, принятые с 15 по 16 января 2024 года
SELECT OrderNumber, AcceptanceDate, Notes
FROM Orders
WHERE CAST(AcceptanceDate AS DATE) BETWEEN '2024-01-15' AND '2024-01-16';

-- Найти услуги стоимостью от 1000 до 2500 рублей
SELECT ServiceName, BasePrice, StandardTime
FROM Services
WHERE BasePrice BETWEEN 1000 AND 2500;


