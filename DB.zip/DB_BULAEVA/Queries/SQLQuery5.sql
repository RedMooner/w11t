-- Найти клиентов с фамилией, начинающейся на 'Ив' 
SELECT FirstName, LastName, PhoneNumber, Email
FROM Clients
WHERE LastName LIKE 'Ив%';

-- Найти автомобили, модель которых содержит 'R' 
SELECT Make, Model, Year, LicensePlate
FROM Cars
WHERE Model LIKE '%r%';

-- Найти сотрудников с телефоном в формате +7-999-xxx-xx-xx
SELECT FullName, PhoneNumber, Position
FROM Employees
WHERE PhoneNumber LIKE '+7-999-%-__-__';





