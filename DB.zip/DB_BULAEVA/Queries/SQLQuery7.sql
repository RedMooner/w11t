-- Найти заказы со статусами "Принят" или "В работе"
SELECT OrderNumber, StatusID, AcceptanceDate
FROM Orders
WHERE StatusID IN (1, 2);  -- 1=Принят, 2=В работе

-- Найти автомобили определенных марок
SELECT Make, Model, Year, ClientID
FROM Cars
WHERE Make IN ('Toyota', 'BMW', 'Honda');

-- Найти сотрудников с конкретными должностями
SELECT FullName, Position, PhoneNumber
FROM Employees
WHERE Position IN ('Старший механик', 'Механик');