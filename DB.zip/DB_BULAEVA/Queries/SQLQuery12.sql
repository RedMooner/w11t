-- Все автомобили и их заказы (даже если заказов нет)
SELECT 
    ca.Make,
    ca.Model,
    ca.LicensePlate,
    o.OrderNumber,
    o.AcceptanceDate,
    ISNULL(s.StatusName, 'Нет заказов') AS Status
FROM Cars ca
LEFT JOIN Orders o ON ca.CarID = o.CarID
LEFT JOIN OrderStatuses s ON o.StatusID = s.StatusID
ORDER BY ca.Make, ca.Model;

-- Все клиенты и их автомобили
SELECT 
    cl.LastName + ' ' + cl.FirstName AS ClientName,
    cl.PhoneNumber,
    ca.Make,
    ca.Model,
    ca.Year,
    ISNULL(ca.LicensePlate, 'Нет номера') AS LicensePlate
FROM Clients cl
LEFT JOIN Cars ca ON cl.ClientID = ca.ClientID
ORDER BY cl.LastName, cl.FirstName;