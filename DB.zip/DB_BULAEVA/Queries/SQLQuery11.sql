-- Информация о заказах с данными клиентов и автомобилей
SELECT 
    o.OrderNumber,
    c.LastName + ' ' + c.FirstName AS ClientName,
    ca.Make + ' ' + ca.Model AS CarName,
    ca.LicensePlate,
    s.StatusName,
    o.AcceptanceDate
FROM Orders o
INNER JOIN Cars ca ON o.CarID = ca.CarID
INNER JOIN Clients c ON ca.ClientID = c.ClientID
INNER JOIN OrderStatuses s ON o.StatusID = s.StatusID;

-- Детализация заказа с услугами и их стоимостью
SELECT 
    o.OrderNumber,
    s.ServiceName,
    os.Quantity,
    s.BasePrice AS StandardPrice,
    ISNULL(os.ActualPrice, s.BasePrice) AS FinalPrice,
    (ISNULL(os.ActualPrice, s.BasePrice) * os.Quantity) AS TotalCost
FROM Orders o
INNER JOIN OrderServices os ON o.OrderID = os.OrderID
INNER JOIN Services s ON os.ServiceID = s.ServiceID
ORDER BY o.OrderNumber;

